#!/usr/bin/env python3
"""
RAG Client – uses FAISS + metadata.json
"""

import faiss
import json
import numpy as np

def load_faiss():
    index = faiss.read_index("faiss_index.bin")
    with open("metadata.json", "r") as f:
        metadata = json.load(f)
    return index, metadata

def search(query_emb, index, metadata, k=3):
    query_emb = np.array(query_emb).astype("float32").reshape(1, -1)
    dist, idxs = index.search(query_emb, k)

    results = []
    for i in idxs[0]:
        if i < len(metadata):
            results.append(metadata[i])
    return results

def format_docs(results):
    text = "### NASA Retrieved Context ###\n\n"
    for n, item in enumerate(results):
        text += f"[{n+1}] Source: {item['source']} | Mission: {item['mission']}\n"
        text += item["text"] + "\n\n"
    return text

