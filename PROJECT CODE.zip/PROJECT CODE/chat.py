#!/usr/bin/env python3
import streamlit as st
import os
import json
import pandas as pd

from sentence_transformers import SentenceTransformer, util
import rag_client

from pathlib import Path
from typing import Dict, List, Optional

# Load embedding model once
embedder = SentenceTransformer("all-MiniLM-L6-v2")

def local_generate_answer(query, context_docs):
    """
    Very simple local answer generator:
    → returns the most relevant sentence from retrieved docs
    """

    if not context_docs:
        return "I cannot find that information in the provided NASA documents."

    # Choose the longest/highest-info doc
    best_doc = max(context_docs, key=len)

    return f"Based on the NASA documents: {best_doc[:500]}..."

def main():
    st.title("🚀 NASA RAG Chat (LOCAL EDITION)")
    st.write("This version uses FAISS + MiniLM only (no OpenAI, no GPT4All).")

    # Load FAISS index + metadata
    st.info("Loading FAISS index...")
    faiss_index_path = "faiss_index.bin"
    metadata_path = "metadata.json"

    if not (os.path.exists(faiss_index_path) and os.path.exists(metadata_path)):
        st.error("FAISS data not found. Run the embedding pipeline first.")
        st.stop()

    import faiss
    index = faiss.read_index(faiss_index_path)

    with open(metadata_path, "r") as f:
        metadata = json.load(f)

    # Chat interface
    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    if user_input := st.chat_input("Ask about NASA missions..."):
        st.session_state.messages.append({"role": "user", "content": user_input})

        # Embed query
        q_emb = embedder.encode([user_input])

        # Retrieve from FAISS
        D, I = index.search(q_emb, 5)

        docs = [metadata[i]["text"] for i in I[0] if i < len(metadata)]

        # Generate local answer
        answer = local_generate_answer(user_input, docs)

        st.session_state.messages.append({"role": "assistant", "content": answer})
        st.rerun()


if __name__ == "__main__":
    main()



