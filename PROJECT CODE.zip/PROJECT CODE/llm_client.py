#!/usr/bin/env python3
"""
Local GPT4All model wrapper for RAG Chat
"""

from gpt4all import GPT4All

# Load model once
model = GPT4All("ggml-gpt4all-j-v1.3-groovy.bin")

def generate(prompt: str) -> str:
    return model.generate(prompt, max_tokens=500)

