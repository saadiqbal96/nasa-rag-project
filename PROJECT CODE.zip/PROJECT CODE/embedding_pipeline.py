#!/usr/bin/env python3
"""
Local Embedding Pipeline for NASA RAG
Uses MiniLM embeddings + FAISS
No OpenAI API required.
"""

import os
import json
import faiss
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple
from sentence_transformers import SentenceTransformer

# ===============================
# SETTINGS
# ===============================
CHUNK_SIZE = 800
CHUNK_OVERLAP = 200
EMBEDDING_MODEL = "all-MiniLM-L6-v2"


# ===============================
# CHUNKING FUNCTION
# ===============================
def chunk_text(text: str, size: int, overlap: int) -> List[str]:
    chunks = []
    start = 0

    while start < len(text):
        end = start + size
        chunk = text[start:end]
        chunks.append(chunk)
        start += size - overlap

    return chunks


# ===============================
# FILE PROCESSING
# ===============================
def detect_mission(filename: str) -> str:
    f = filename.lower()
    if "11" in f:
        return "Apollo 11"
    if "13" in f:
        return "Apollo 13"
    if "challenger" in f or "ch" in f:
        return "Challenger"
    return "Unknown"


def load_txt_files() -> List[Path]:
    txts = list(Path("starter_files").rglob("*.txt"))
    print(f"\nFound TXT files: {txts}\n")
    return txts


# ===============================
# MAIN PIPELINE
# ===============================
def main():
    print("Loading embedding model (MiniLM)...")
    embedder = SentenceTransformer(EMBEDDING_MODEL)

    txt_files = load_txt_files()
    all_embeddings = []
    metadata_list = []

    for path in txt_files:
        print(f"Processing {path.name}...")

        text = path.read_text(errors="ignore")
        chunks = chunk_text(text, CHUNK_SIZE, CHUNK_OVERLAP)

        mission = detect_mission(path.name)

        for chunk in chunks:
            emb = embedder.encode(chunk)
            emb = np.array(emb).astype("float32")

            all_embeddings.append(emb)

            metadata_list.append({
                "text": chunk,
                "source": path.name,
                "mission": mission
            })

    # Convert to FAISS-friendly matrix
    matrix = np.vstack(all_embeddings)

    print("Creating new FAISS index...")
    dim = matrix.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(matrix)

    # Save FAISS index
    faiss.write_index(index, "faiss_index.bin")

    # Save metadata
    with open("metadata.json", "w") as f:
        json.dump(metadata_list, f, indent=2)

    print("\nFAISS index + metadata saved.")
    print("Embedding completed successfully!\n")


if __name__ == "__main__":
    main()





