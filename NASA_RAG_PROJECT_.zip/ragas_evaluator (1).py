import numpy as np

# ----------------------------------------------------
# Simple RAG evaluation — NO ragas library required
# ----------------------------------------------------
def score_relevancy(answer, context):
    """
    Relevancy score:
    - 1.0 if the answer mentions ANY keyword from the context.
    - 0.0 if not.
    """
    answer = answer.lower()
    context = context.lower()

    keywords = []
    for w in context.split():
        if len(w) > 5:          # avoid "the", "and", etc.
            keywords.append(w)

    if any(k in answer for k in keywords[:20]):  
        return 1.0
    return 0.0


def score_faithfulness(answer, ground_truth):
    """
    Faithfulness score:
    - Max score 1.0
    - The more overlap with ground truth, the higher the score
    """
    a = answer.lower().split()
    t = ground_truth.lower().split()

    if len(t) == 0:
        return 0.0

    overlap = len(set(a).intersection(set(t)))
    return overlap / len(t)


def evaluate_response(answer, context, truth):
    """
    Calculate both scores.
    """
    return {
        "relevancy": score_relevancy(answer, context),
        "faithfulness": score_faithfulness(answer, truth),
    }
