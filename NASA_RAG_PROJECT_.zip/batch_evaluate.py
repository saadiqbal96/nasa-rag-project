"""
Batch evaluation script for the NASA RAG project.
Loads evaluation_dataset.json, runs retrieval -> context -> LLM stub,
then evaluates using ragas_evaluator.
"""

import json
from pathlib import Path
import sys

sys.path.append("/content/nasa_rag_project")

from rag_client import retrieve, format_context
from llm_client import generate_response
from ragas_evaluator import evaluate_response


def run_batch_evaluation():
    dataset_path = "/content/evaluation_dataset.json"

    print("📘 Loading evaluation dataset:", dataset_path)

    with open(dataset_path, "r") as f:
        dataset = json.load(f)

    results = []

    for item in dataset:
        q = item["question"]
        t = item["truth"]

        print("\n=====================================")
        print("❓ QUESTION:", q)

        # RETRIEVE
        docs, metas = retrieve(q, k=3)
        ctx = format_context(docs, metas)

        # LLM STUB RESPONSE
        ans = generate_response(q, ctx)
        print("🤖 ANSWER:", ans[:200], "...")

        # EVALUATE
        scores = evaluate_response(q, ans, t)
        print("📊 SCORES:", scores)

        results.append({
            "question": q,
            "answer": ans,
            "truth": t,
            "scores": scores
        })

    # Save results
    out_file = "/content/evaluation_results.json"
    with open(out_file, "w") as f:
        json.dump(results, f, indent=2)

    print("\n✅ Batch evaluation complete!")
    print("📁 Results saved to:", out_file)
