import json
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

# Load embedding model once
model = SentenceTransformer("all-MiniLM-L6-v2")

def load_faiss():
    index = faiss.read_index("/content/nasa_rag_project/embeddings/faiss.index")
    metadata = json.load(open("/content/nasa_rag_project/embeddings/metadata.json"))
    return index, metadata

def retrieve(query, k=3, mission_filter=None):
    index, metadata = load_faiss()

    # Encode query
    q_emb = model.encode([query]).astype("float32")
    distances, idxs = index.search(q_emb, k)

    docs = []
    metas = []
    seen = set()

    for rank, i in enumerate(idxs[0]):
        if i == -1:
            continue

        md = metadata[i]

        # mission filter
        if mission_filter and md["mission"] != mission_filter:
            continue

        if md["text"] in seen:
            continue
        seen.add(md["text"])

        docs.append(md["text"])
        metas.append({
            "source": md["source"],
            "mission": md["mission"],
            "score": float(distances[0][rank])
        })

    return docs, metas

def format_context(docs, metas):
    blocks = []
    for i, doc in enumerate(docs):
        m = metas[i]
        blocks.append(
            f"[Source: {m['source']} | Mission: {m['mission']} | Score: {m['score']:.3f}]\n{doc}\n---"
        )
    return "\n".join(blocks)
