"""
Local LLM simulation for NASA RAG.
This version works offline and does NOT call any OpenAI API.
"""

def generate_response(question, context):
    """
    Simulated LLM: returns a structured answer using the retrieved context.
    """
    answer = f"### Simulated NASA RAG Response\n"
    answer += f"**Question:** {question}\n\n"
    answer += f"**Context Length:** {len(context)} characters\n\n"
    answer += (
        "This is a simulated LLM response (offline mode). "
        "Your real answer will depend on the context retrieved from NASA logs.\n\n"
    )
    answer += f"---\nRetrieved Context:\n{context[:1500]}...\n"
    return answer
